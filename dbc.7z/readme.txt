下午 11:05 2013/8/29

在dbchat資料夾下的db_ac.php檔案
要手動修改內容
<?php
$dbhost = '資料庫主機位置';
$dbuser = '資料庫使用者';
$dbpass = '資料庫密碼';
$dbname = '資料庫名稱';
?>